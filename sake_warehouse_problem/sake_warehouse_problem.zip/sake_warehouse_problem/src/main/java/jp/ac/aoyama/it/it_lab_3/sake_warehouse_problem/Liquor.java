//15820062 戸田空伽
package jp.ac.aoyama.it.it_lab_3.sake_warehouse_problem;

public class Liquor {
    String brand;
    public Liquor(String brand){
        this.brand=brand;
    }

    String getBrand(){
        return brand;
    }
}
